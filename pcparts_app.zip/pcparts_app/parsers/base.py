# -*- coding: utf-8 -*-
"""
Базовый класс для всех парсеров магазинов.

ВАЖНО (прочитай обязательно):
Каждый сайт время от времени меняет вёрстку (CSS-классы, структуру блоков).
Селекторы ниже — рабочая ОТПРАВНАЯ ТОЧКА, но их придётся периодически
проверять/поправлять через "Просмотр кода страницы" в браузере (F12),
если магазин обновит дизайн.

Также некоторые сайты подгружают товары через JavaScript уже ПОСЛЕ
загрузки страницы. В таком случае requests+BeautifulSoup увидит пустой
список товаров, потому что JS ещё не выполнился. Если так — придётся:
  a) искать скрытый JSON внутри <script> тегов страницы (часто данные
     всё равно есть в HTML в виде JSON, просто не отрисованы), либо
  b) переходить на playwright/selenium (тяжелее, но рендерит JS).
"""

import requests
from bs4 import BeautifulSoup

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "pl-PL,pl;q=0.9,en;q=0.8",
}


class BaseParser:
    store_key = "base"
    store_name = "Base Store"
    search_url_template = ""  # переопределяется в наследниках

    def build_search_url(self, query):
        return self.search_url_template.format(query=query.replace(" ", "+"))

    def fetch_html(self, url, timeout=10):
        resp = requests.get(url, headers=HEADERS, timeout=timeout)
        resp.raise_for_status()
        return resp.text

    def parse(self, query):
        """Возвращает список словарей-товаров. Переопределяется в наследниках."""
        raise NotImplementedError

    def safe_parse(self, query):
        """Обёртка: не роняет всё приложение, если один сайт недоступен/изменился."""
        try:
            return self.parse(query)
        except Exception as e:
            print(f"[{self.store_key}] Ошибка парсинга: {e}")
            return []

    @staticmethod
    def clean_price(text):
        """'2 499,00 zł' -> 2499.00"""
        if not text:
            return None
        digits = "".join(c for c in text if c.isdigit() or c in ",.")
        digits = digits.replace(" ", "").replace(",", ".")
        parts = digits.split(".")
        if len(parts) > 2:
            digits = "".join(parts[:-1]) + "." + parts[-1]
        try:
            return float(digits)
        except ValueError:
            return None
