# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
from .base import BaseParser


class RtvEuroAgdParser(BaseParser):
    store_key = "rtv_euro_agd"
    store_name = "RTV Euro AGD"
    search_url_template = "https://www.euro.com.pl/szukaj.bhtml?keyword={query}"

    def parse(self, query):
        html = self.fetch_html(self.build_search_url(query))
        soup = BeautifulSoup(html, "html.parser")
        items = []

        cards = soup.select("div.product-tile, li.product-list-item, article.product")

        for card in cards:
            title_el = card.select_one(".product-tile__title, .name, h3, a.product-name")
            price_el = card.select_one(".price, .product-tile__price, .price-value")
            link_el = card.select_one("a")
            img_el = card.select_one("img")

            if not title_el:
                continue

            title = title_el.get_text(strip=True)
            price = self.clean_price(price_el.get_text(strip=True) if price_el else None)
            url = link_el.get("href") if link_el else None
            if url and url.startswith("/"):
                url = "https://www.euro.com.pl" + url

            items.append({
                "store_key": self.store_key,
                "store_name": self.store_name,
                "title": title,
                "price": price,
                "url": url,
                "desc": "",
                "condition": "new",
                "in_stock": True,
                "image": img_el.get("src") if img_el else None,
            })

        return items
