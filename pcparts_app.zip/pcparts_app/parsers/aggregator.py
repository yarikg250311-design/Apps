# -*- coding: utf-8 -*-
from concurrent.futures import ThreadPoolExecutor, as_completed

from .media_expert import MediaExpertParser
from .media_markt import MediaMarktParser
from .neonet import NeonetParser
from .rtv_euro_agd import RtvEuroAgdParser

# Цвет-полоска карточки под каждый магазин (RGBA, 0..1) + сам класс парсера
STORES = {
    "media_expert": {"name": "Media Expert", "color": [0.85, 0.1, 0.1, 1], "parser": MediaExpertParser},
    "media_markt": {"name": "Media Markt", "color": [0.85, 0.05, 0.4, 1], "parser": MediaMarktParser},
    "neonet": {"name": "Neonet", "color": [0.1, 0.55, 0.85, 1], "parser": NeonetParser},
    "rtv_euro_agd": {"name": "RTV Euro AGD", "color": [0.1, 0.65, 0.3, 1], "parser": RtvEuroAgdParser},
}


def search_all_stores(query, stores=None):
    """
    Запускает поиск по нескольким магазинам параллельно (в потоках),
    чтобы не ждать каждый сайт по очереди.
    stores: список ключей магазинов для поиска (например ["media_expert", "neonet"]).
            Если None - ищем везде.
    """
    active_keys = stores if stores else list(STORES.keys())
    results = []

    with ThreadPoolExecutor(max_workers=len(active_keys) or 1) as executor:
        future_to_store = {}
        for key in active_keys:
            store_info = STORES.get(key)
            if not store_info:
                continue
            parser = store_info["parser"]()
            future = executor.submit(parser.safe_parse, query)
            future_to_store[future] = key

        for future in as_completed(future_to_store):
            try:
                store_results = future.result()
                results.extend(store_results)
            except Exception as e:
                print("Ошибка потока парсинга:", e)

    return results
