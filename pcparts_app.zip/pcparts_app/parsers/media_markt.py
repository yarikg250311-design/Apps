# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
from .base import BaseParser


class MediaMarktParser(BaseParser):
    store_key = "media_markt"
    store_name = "Media Markt"
    search_url_template = "https://mediamarkt.pl/pl/search?query={query}"

    def parse(self, query):
        html = self.fetch_html(self.build_search_url(query))
        soup = BeautifulSoup(html, "html.parser")
        items = []

        # ВАЖНО: MediaMarkt в PL часто рендерит список товаров через JS
        # (React/Next.js). Если cards получится пустым - смотри комментарий
        # в base.py про поиск JSON внутри <script type="application/ld+json">
        # или <script id="__NEXT_DATA__"> - там обычно дублируются данные
        # в виде обычного текста/JSON, доступного requests+BeautifulSoup.
        cards = soup.select("div[data-test='mms-product-card'], div.product-card, li.product-item")

        for card in cards:
            title_el = card.select_one("[data-test='product-title'], .product-title, h2, h3")
            price_el = card.select_one("[data-test='price'], .price")
            link_el = card.select_one("a")
            img_el = card.select_one("img")

            if not title_el:
                continue

            title = title_el.get_text(strip=True)
            price = self.clean_price(price_el.get_text(strip=True) if price_el else None)
            url = link_el.get("href") if link_el else None
            if url and url.startswith("/"):
                url = "https://mediamarkt.pl" + url

            items.append({
                "store_key": self.store_key,
                "store_name": self.store_name,
                "title": title,
                "price": price,
                "url": url,
                "desc": "",
                "condition": "new",
                "in_stock": True,
                "image": img_el.get("src") if img_el else None,
            })

        return items
