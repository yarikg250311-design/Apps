# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
from .base import BaseParser


class MediaExpertParser(BaseParser):
    store_key = "media_expert"
    store_name = "Media Expert"
    search_url_template = "https://www.mediaexpert.pl/search?query={query}"

    def parse(self, query):
        html = self.fetch_html(self.build_search_url(query))
        soup = BeautifulSoup(html, "html.parser")
        items = []

        # ЗАМЕНИ селекторы ниже, если сайт изменит вёрстку (проверь через F12)
        cards = soup.select("div.offer-box, div.product-tile, article.product")

        for card in cards:
            title_el = card.select_one("p.name, .product-name, h3, a.name")
            price_el = card.select_one(".price, .product-price, .price-value")
            link_el = card.select_one("a")
            img_el = card.select_one("img")

            if not title_el:
                continue

            title = title_el.get_text(strip=True)
            price = self.clean_price(price_el.get_text(strip=True) if price_el else None)
            url = link_el.get("href") if link_el else None
            if url and url.startswith("/"):
                url = "https://www.mediaexpert.pl" + url

            items.append({
                "store_key": self.store_key,
                "store_name": self.store_name,
                "title": title,
                "price": price,
                "url": url,
                "desc": "",
                "condition": "new",
                "in_stock": True,
                "image": img_el.get("src") if img_el else None,
            })

        return items
